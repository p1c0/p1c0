# coding: utf-8

from __future__ import absolute_import
import unittest

from flask import json
from six import BytesIO

from openapi_server.models.error import Error  # noqa: E501
from openapi_server.models.service_order import ServiceOrder  # noqa: E501
from openapi_server.models.service_order_create import ServiceOrderCreate  # noqa: E501
from openapi_server.models.service_order_update import ServiceOrderUpdate  # noqa: E501
from openapi_server.test import BaseTestCase


class TestServiceOrderController(BaseTestCase):
    """ServiceOrderController integration test stubs"""

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_create_service_order(self):
        """Test case for create_service_order

        Creates a ServiceOrder
        """
        service_order = openapi_server.ServiceOrderCreate()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/serviceOrder',
            method='POST',
            headers=headers,
            data=json.dumps(service_order),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_service_order(self):
        """Test case for delete_service_order

        Deletes a ServiceOrder
        """
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/serviceOrder/{id}'.format(id='id_example'),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_service_order(self):
        """Test case for list_service_order

        List or find ServiceOrder objects
        """
        query_string = [('fields', 'fields_example'),
                        ('offset', 56),
                        ('limit', 56)]
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/serviceOrder',
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_patch_service_order(self):
        """Test case for patch_service_order

        Updates partially a ServiceOrder
        """
        service_order = openapi_server.ServiceOrderUpdate()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/serviceOrder/{id}'.format(id='id_example'),
            method='PATCH',
            headers=headers,
            data=json.dumps(service_order),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_retrieve_service_order(self):
        """Test case for retrieve_service_order

        Retrieves a ServiceOrder by ID
        """
        query_string = [('fields', 'fields_example')]
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/serviceOrder/{id}'.format(id='id_example'),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
