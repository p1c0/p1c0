# coding: utf-8

from __future__ import absolute_import
import unittest

from flask import json
from six import BytesIO

from openapi_server.models.error import Error  # noqa: E501
from openapi_server.models.event_subscription import EventSubscription  # noqa: E501
from openapi_server.models.event_subscription_input import EventSubscriptionInput  # noqa: E501
from openapi_server.test import BaseTestCase


class TestEventsSubscriptionController(BaseTestCase):
    """EventsSubscriptionController integration test stubs"""

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_register_listener(self):
        """Test case for register_listener

        Register a listener
        """
        data = openapi_server.EventSubscriptionInput()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/hub',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_unregister_listener(self):
        """Test case for unregister_listener

        Unregister a listener
        """
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/hub/{id}'.format(id='id_example'),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
