import connexion
import six
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.cancel_service_order_create_event import CancelServiceOrderCreateEvent  # noqa: E501
from openapi_server.models.cancel_service_order_information_required_event import CancelServiceOrderInformationRequiredEvent  # noqa: E501
from openapi_server.models.cancel_service_order_state_change_event import CancelServiceOrderStateChangeEvent  # noqa: E501
from openapi_server.models.error import Error  # noqa: E501
from openapi_server.models.event_subscription import EventSubscription  # noqa: E501
from openapi_server.models.service_order_attribute_value_change_event import ServiceOrderAttributeValueChangeEvent  # noqa: E501
from openapi_server.models.service_order_create_event import ServiceOrderCreateEvent  # noqa: E501
from openapi_server.models.service_order_delete_event import ServiceOrderDeleteEvent  # noqa: E501
from openapi_server.models.service_order_information_required_event import ServiceOrderInformationRequiredEvent  # noqa: E501
from openapi_server.models.service_order_jeopardy_event import ServiceOrderJeopardyEvent  # noqa: E501
from openapi_server.models.service_order_milestone_event import ServiceOrderMilestoneEvent  # noqa: E501
from openapi_server.models.service_order_state_change_event import ServiceOrderStateChangeEvent  # noqa: E501
from openapi_server import util


def listen_to_cancel_service_order_create_event(data):  # noqa: E501
    """Client listener for entity CancelServiceOrderCreateEvent

    Example of a client listener for receiving the notification CancelServiceOrderCreateEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = CancelServiceOrderCreateEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def listen_to_cancel_service_order_information_required_event(data):  # noqa: E501
    """Client listener for entity CancelServiceOrderInformationRequiredEvent

    Example of a client listener for receiving the notification CancelServiceOrderInformationRequiredEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = CancelServiceOrderInformationRequiredEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def listen_to_cancel_service_order_state_change_event(data):  # noqa: E501
    """Client listener for entity CancelServiceOrderStateChangeEvent

    Example of a client listener for receiving the notification CancelServiceOrderStateChangeEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = CancelServiceOrderStateChangeEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def listen_to_service_order_attribute_value_change_event(data):  # noqa: E501
    """Client listener for entity ServiceOrderAttributeValueChangeEvent

    Example of a client listener for receiving the notification ServiceOrderAttributeValueChangeEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = ServiceOrderAttributeValueChangeEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def listen_to_service_order_create_event(data):  # noqa: E501
    """Client listener for entity ServiceOrderCreateEvent

    Example of a client listener for receiving the notification ServiceOrderCreateEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = ServiceOrderCreateEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def listen_to_service_order_delete_event(data):  # noqa: E501
    """Client listener for entity ServiceOrderDeleteEvent

    Example of a client listener for receiving the notification ServiceOrderDeleteEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = ServiceOrderDeleteEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def listen_to_service_order_information_required_event(data):  # noqa: E501
    """Client listener for entity ServiceOrderInformationRequiredEvent

    Example of a client listener for receiving the notification ServiceOrderInformationRequiredEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = ServiceOrderInformationRequiredEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def listen_to_service_order_jeopardy_event(data):  # noqa: E501
    """Client listener for entity ServiceOrderJeopardyEvent

    Example of a client listener for receiving the notification ServiceOrderJeopardyEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = ServiceOrderJeopardyEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def listen_to_service_order_milestone_event(data):  # noqa: E501
    """Client listener for entity ServiceOrderMilestoneEvent

    Example of a client listener for receiving the notification ServiceOrderMilestoneEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = ServiceOrderMilestoneEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def listen_to_service_order_state_change_event(data):  # noqa: E501
    """Client listener for entity ServiceOrderStateChangeEvent

    Example of a client listener for receiving the notification ServiceOrderStateChangeEvent # noqa: E501

    :param data: The event data
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = ServiceOrderStateChangeEvent.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
