import connexion
import six
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.error import Error  # noqa: E501
from openapi_server.models.event_subscription import EventSubscription  # noqa: E501
from openapi_server.models.event_subscription_input import EventSubscriptionInput  # noqa: E501
from openapi_server import util


def register_listener(data):  # noqa: E501
    """Register a listener

    Sets the communication endpoint address the service instance must use to deliver information about its health state, execution state, failures and metrics. # noqa: E501

    :param data: Data containing the callback endpoint to deliver the information
    :type data: dict | bytes

    :rtype: Union[EventSubscription, Tuple[EventSubscription, int], Tuple[EventSubscription, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        data = EventSubscriptionInput.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def unregister_listener(id):  # noqa: E501
    """Unregister a listener

    Resets the communication endpoint address the service instance must use to deliver information about its health state, execution state, failures and metrics. # noqa: E501

    :param id: The id of the registered listener
    :type id: str

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'
