# coding: utf-8

from __future__ import absolute_import
import unittest

from flask import json
from six import BytesIO

from openapi_server.models.cancel_service_order_create_event import CancelServiceOrderCreateEvent  # noqa: E501
from openapi_server.models.cancel_service_order_information_required_event import CancelServiceOrderInformationRequiredEvent  # noqa: E501
from openapi_server.models.cancel_service_order_state_change_event import CancelServiceOrderStateChangeEvent  # noqa: E501
from openapi_server.models.error import Error  # noqa: E501
from openapi_server.models.event_subscription import EventSubscription  # noqa: E501
from openapi_server.models.service_order_attribute_value_change_event import ServiceOrderAttributeValueChangeEvent  # noqa: E501
from openapi_server.models.service_order_create_event import ServiceOrderCreateEvent  # noqa: E501
from openapi_server.models.service_order_delete_event import ServiceOrderDeleteEvent  # noqa: E501
from openapi_server.models.service_order_information_required_event import ServiceOrderInformationRequiredEvent  # noqa: E501
from openapi_server.models.service_order_jeopardy_event import ServiceOrderJeopardyEvent  # noqa: E501
from openapi_server.models.service_order_milestone_event import ServiceOrderMilestoneEvent  # noqa: E501
from openapi_server.models.service_order_state_change_event import ServiceOrderStateChangeEvent  # noqa: E501
from openapi_server.test import BaseTestCase


class TestNotificationListenersClientSideController(BaseTestCase):
    """NotificationListenersClientSideController integration test stubs"""

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_cancel_service_order_create_event(self):
        """Test case for listen_to_cancel_service_order_create_event

        Client listener for entity CancelServiceOrderCreateEvent
        """
        data = openapi_server.CancelServiceOrderCreateEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/cancelServiceOrderCreateEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_cancel_service_order_information_required_event(self):
        """Test case for listen_to_cancel_service_order_information_required_event

        Client listener for entity CancelServiceOrderInformationRequiredEvent
        """
        data = openapi_server.CancelServiceOrderInformationRequiredEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/cancelServiceOrderInformationRequiredEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_cancel_service_order_state_change_event(self):
        """Test case for listen_to_cancel_service_order_state_change_event

        Client listener for entity CancelServiceOrderStateChangeEvent
        """
        data = openapi_server.CancelServiceOrderStateChangeEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/cancelServiceOrderStateChangeEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_service_order_attribute_value_change_event(self):
        """Test case for listen_to_service_order_attribute_value_change_event

        Client listener for entity ServiceOrderAttributeValueChangeEvent
        """
        data = openapi_server.ServiceOrderAttributeValueChangeEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/serviceOrderAttributeValueChangeEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_service_order_create_event(self):
        """Test case for listen_to_service_order_create_event

        Client listener for entity ServiceOrderCreateEvent
        """
        data = openapi_server.ServiceOrderCreateEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/serviceOrderCreateEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_service_order_delete_event(self):
        """Test case for listen_to_service_order_delete_event

        Client listener for entity ServiceOrderDeleteEvent
        """
        data = openapi_server.ServiceOrderDeleteEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/serviceOrderDeleteEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_service_order_information_required_event(self):
        """Test case for listen_to_service_order_information_required_event

        Client listener for entity ServiceOrderInformationRequiredEvent
        """
        data = openapi_server.ServiceOrderInformationRequiredEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/serviceOrderInformationRequiredEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_service_order_jeopardy_event(self):
        """Test case for listen_to_service_order_jeopardy_event

        Client listener for entity ServiceOrderJeopardyEvent
        """
        data = openapi_server.ServiceOrderJeopardyEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/serviceOrderJeopardyEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_service_order_milestone_event(self):
        """Test case for listen_to_service_order_milestone_event

        Client listener for entity ServiceOrderMilestoneEvent
        """
        data = openapi_server.ServiceOrderMilestoneEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/serviceOrderMilestoneEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    @unittest.skip("application/json;charset&#x3D;utf-8 not supported by Connexion")
    def test_listen_to_service_order_state_change_event(self):
        """Test case for listen_to_service_order_state_change_event

        Client listener for entity ServiceOrderStateChangeEvent
        """
        data = openapi_server.ServiceOrderStateChangeEvent()
        headers = { 
            'Accept': 'application/json;charset&#x3D;utf-8',
            'Content-Type': 'application/json;charset&#x3D;utf-8',
        }
        response = self.client.open(
            '/tmf-api/serviceOrdering/v4/listener/serviceOrderStateChangeEvent',
            method='POST',
            headers=headers,
            data=json.dumps(data),
            content_type='application/json;charset=utf-8')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
