import connexion
import six
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.error import Error  # noqa: E501
from openapi_server.models.service_order import ServiceOrder  # noqa: E501
from openapi_server.models.service_order_create import ServiceOrderCreate  # noqa: E501
from openapi_server.models.service_order_update import ServiceOrderUpdate  # noqa: E501
from openapi_server import util


def create_service_order():  # noqa: E501
    # print(service_order)
    # import pdb;
    # pdb.set_trace()
    """Creates a ServiceOrder

    This operation creates a ServiceOrder entity. # noqa: E501

    :param service_order: The ServiceOrder to be created
    :type service_order: dict | bytes

    :rtype: Union[ServiceOrder, Tuple[ServiceOrder, int], Tuple[ServiceOrder, int, Dict[str, str]]
    """

    if connexion.request.is_json:
        service_order = ServiceOrderCreate.from_dict(connexion.request.get_json())  # noqa: E501
    # import pdb;
    # pdb.set_trace()
    return service_order


def delete_service_order(id):  # noqa: E501
    """Deletes a ServiceOrder

    This operation deletes a ServiceOrder entity. # noqa: E501

    :param id: Identifier of the ServiceOrder
    :type id: str

    :rtype: Union[None, Tuple[None, int], Tuple[None, int, Dict[str, str]]
    """
    return 'do some magic!'


def list_service_order(fields=None, offset=None, limit=None):  # noqa: E501
    """List or find ServiceOrder objects

    This operation list or find ServiceOrder entities # noqa: E501

    :param fields: Comma-separated properties to be provided in response
    :type fields: str
    :param offset: Requested index for start of resources to be provided in response
    :type offset: int
    :param limit: Requested number of resources to be provided in response
    :type limit: int

    :rtype: Union[List[ServiceOrder], Tuple[List[ServiceOrder], int], Tuple[List[ServiceOrder], int, Dict[str, str]]
    """
    print(ServiceOrder)
    prop = getattr(ServiceOrder, "cancellation_date")
    res = ServiceOrder()
    data = prop.fget(res)
    print(data)
    # import pdb;
    # pdb.set_trace()
    # return service_order
    return "I am here"
    # return 'do some magic!'


def patch_service_order(id, service_order):  # noqa: E501
    """Updates partially a ServiceOrder

    This operation updates partially a ServiceOrder entity. # noqa: E501

    :param id: Identifier of the ServiceOrder
    :type id: str
    :param service_order: The ServiceOrder to be updated
    :type service_order: dict | bytes

    :rtype: Union[ServiceOrder, Tuple[ServiceOrder, int], Tuple[ServiceOrder, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        service_order = ServiceOrderUpdate.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def retrieve_service_order(id, fields=None):  # noqa: E501
    """Retrieves a ServiceOrder by ID

    This operation retrieves a ServiceOrder entity. Attribute selection is enabled for all first level attributes. # noqa: E501

    :param id: Identifier of the ServiceOrder
    :type id: str
    :param fields: Comma-separated properties to provide in response
    :type fields: str

    :rtype: Union[ServiceOrder, Tuple[ServiceOrder, int], Tuple[ServiceOrder, int, Dict[str, str]]
    """
    return 'do some magic!'
